package ThePointandLine;

public class LineSub {

}
