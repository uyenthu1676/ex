package ThePointandLine;

public class Point {

}
