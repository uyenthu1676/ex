package ballAndContainer;

public class Ball {
    private int x, y, radius;
    private double xDelta, yDelta;

    public Ball(int x, int y, int radius, int speed, int direction) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        
        double radians = Math.toRadians(direction);
        this.xDelta = speed * Math.cos(radians);
        this.yDelta = -speed * Math.sin(radians);  
    }

    public int getX() { return x; }
    public void setX(int x) { this.x = x; }

    public int getY() { return y; }
    public void setY(int y) { this.y = y; }

    public int getRadius() { return radius; }
    public void setRadius(int radius) { this.radius = radius; }

    public double getXDelta() { return xDelta; }
    public void setXDelta(double xDelta) { this.xDelta = xDelta; }

    public double getYDelta() { return yDelta; }
    public void setYDelta(double yDelta) { this.yDelta = yDelta; }

    public void move() {
        x += (int) xDelta;
        y += (int) yDelta;
    }

    public void reflectHorizontal() {
        xDelta = -xDelta;
    }

    public void reflectVertical() {
        yDelta = -yDelta;
    }

    @Override
    public String toString() {
        return "Ball at (" + x + ", " + y + ") of velocity (" + xDelta + ", " + yDelta + ")";
    }
}
