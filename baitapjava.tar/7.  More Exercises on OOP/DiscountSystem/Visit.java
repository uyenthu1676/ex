package DiscountSystem;

public class Visit {
	
	private Customer customer;
    private double productTotal; 
    private double serviceTotal; 

    public Visit(Customer customer, double productTotal, double serviceTotal) {
        this.customer = customer;
        this.productTotal = productTotal;
        this.serviceTotal = serviceTotal;
    }

    public double calculateTotal() {
    	
        String membershipType = customer.getMembershipType();
        
        double productDiscount = DiscountRate.getProductDiscount();
        double productTotalAfterDiscount = productTotal * (1 - productDiscount);

        
        double serviceDiscount = DiscountRate.getServiceDiscount(membershipType);
        double serviceTotalAfterDiscount = serviceTotal * (1 - serviceDiscount);
        
        
        return productTotalAfterDiscount + serviceTotalAfterDiscount;
    }


}
