package DiscountSystem;

public class Customer {
	private String name;
    private String membershipType; // Membership types can be Premium, Gold, Silver, or None

    public Customer(String name, String membershipType) {
        this.name = name;
        this.membershipType = membershipType;
    }

    public String getMembershipType() {
        return membershipType;
    }

    public String getName() {
        return name;

}
}
