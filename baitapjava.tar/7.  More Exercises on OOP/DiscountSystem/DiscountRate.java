package DiscountSystem;

public class DiscountRate {
	
    public static final double PREMIUM_SERVICE_DISCOUNT = 0.20;  
    public static final double GOLD_SERVICE_DISCOUNT = 0.15;     
    public static final double SILVER_SERVICE_DISCOUNT = 0.10;   
    public static final double NO_SERVICE_DISCOUNT = 0.00;       
    public static final double PRODUCT_DISCOUNT = 0.10;         
    
    public static double getServiceDiscount(String membershipType) {
        switch (membershipType) {
            case "Premium":
                return PREMIUM_SERVICE_DISCOUNT;
            case "Gold":
                return GOLD_SERVICE_DISCOUNT;
            case "Silver":
                return SILVER_SERVICE_DISCOUNT;
            default:
                return NO_SERVICE_DISCOUNT; 
        }
    }

    
    public static double getProductDiscount() {
        return PRODUCT_DISCOUNT;
    }
}
