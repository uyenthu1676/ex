package DiscountSystem;

public class TestDiscountSystem {
    public static void main(String[] args) {

	 Customer customer1 = new Customer("Alice", "Premium");
     Customer customer2 = new Customer("Bob", "Gold");
     Customer customer3 = new Customer("Charlie", "Silver");
     Customer customer4 = new Customer("David", "None");
     
    
     Visit visit1 = new Visit(customer1, 100, 200);  
     Visit visit2 = new Visit(customer2, 150, 300);  
     Visit visit3 = new Visit(customer3, 120, 250);  
     Visit visit4 = new Visit(customer4, 80, 150);   
     
     
     System.out.printf("Alice's total bill: $%.2f\n", visit1.calculateTotal());
     System.out.printf("Bob's total bill: $%.2f\n", visit2.calculateTotal());
     System.out.printf("Charlie's total bill: $%.2f\n", visit3.calculateTotal());
     System.out.printf("David's total bill: $%.2f\n", visit4.calculateTotal());
 
    }
}
