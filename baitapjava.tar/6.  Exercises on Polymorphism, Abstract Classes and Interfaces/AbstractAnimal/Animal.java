package AbstractAnimal;

abstract public class Animal {
	public abstract void greeting();

}
