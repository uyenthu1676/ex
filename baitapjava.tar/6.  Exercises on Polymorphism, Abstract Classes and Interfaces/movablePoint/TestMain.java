package movablePoint;

public class TestMain {
	 public static void main(String[] args) {
	        
	    }

}
